﻿namespace StoreBoxes
{
    public class Item
    {
        public string Name { get; set; }
        public double Price { get; set; }
    }
}
